#ifndef TOOLSENUM_H
#define TOOLSENUM_H

enum Tools
{
    Initial,
    Move,
    Draw,
    Fill,
    DrawFigure,
    Copy,
    Paste
};

#endif // TOOLSENUM_H
