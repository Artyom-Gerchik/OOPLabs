/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../LAB2/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[52];
    char stringdata0[429];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 9), // "slotTimer"
QT_MOC_LITERAL(21, 0), // ""
QT_MOC_LITERAL(22, 22), // "figures_draw_rectangle"
QT_MOC_LITERAL(45, 20), // "figures_draw_ellipse"
QT_MOC_LITERAL(66, 20), // "figures_draw_polygon"
QT_MOC_LITERAL(87, 17), // "figures_draw_line"
QT_MOC_LITERAL(105, 19), // "figures_draw_broken"
QT_MOC_LITERAL(125, 22), // "figures_draw_freestyle"
QT_MOC_LITERAL(148, 10), // "tools_move"
QT_MOC_LITERAL(159, 22), // "tools_choose_pen_color"
QT_MOC_LITERAL(182, 28), // "tools_choose_floodfill_color"
QT_MOC_LITERAL(211, 10), // "tools_undo"
QT_MOC_LITERAL(222, 10), // "tools_redo"
QT_MOC_LITERAL(233, 14), // "tools_scale_up"
QT_MOC_LITERAL(248, 16), // "tools_scale_down"
QT_MOC_LITERAL(265, 18), // "tools_rotate_right"
QT_MOC_LITERAL(284, 17), // "tools_rotate_left"
QT_MOC_LITERAL(302, 10), // "tools_copy"
QT_MOC_LITERAL(313, 11), // "tools_paste"
QT_MOC_LITERAL(325, 12), // "tools_delete"
QT_MOC_LITERAL(338, 15), // "tools_serialize"
QT_MOC_LITERAL(354, 18), // "tools_de_serialize"
QT_MOC_LITERAL(373, 27), // "on_penWidthBox_valueChanged"
QT_MOC_LITERAL(401, 4), // "arg1"
QT_MOC_LITERAL(406, 22) // "on_choseButton_clicked"

    },
    "MainWindow\0slotTimer\0\0figures_draw_rectangle\0"
    "figures_draw_ellipse\0figures_draw_polygon\0"
    "figures_draw_line\0figures_draw_broken\0"
    "figures_draw_freestyle\0tools_move\0"
    "tools_choose_pen_color\0"
    "tools_choose_floodfill_color\0tools_undo\0"
    "tools_redo\0tools_scale_up\0tools_scale_down\0"
    "tools_rotate_right\0tools_rotate_left\0"
    "tools_copy\0tools_paste\0tools_delete\0"
    "tools_serialize\0tools_de_serialize\0"
    "on_penWidthBox_valueChanged\0arg1\0"
    "on_choseButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  152,    2, 0x08,    1 /* Private */,
       3,    0,  153,    2, 0x08,    2 /* Private */,
       4,    0,  154,    2, 0x08,    3 /* Private */,
       5,    0,  155,    2, 0x08,    4 /* Private */,
       6,    0,  156,    2, 0x08,    5 /* Private */,
       7,    0,  157,    2, 0x08,    6 /* Private */,
       8,    0,  158,    2, 0x08,    7 /* Private */,
       9,    0,  159,    2, 0x08,    8 /* Private */,
      10,    0,  160,    2, 0x08,    9 /* Private */,
      11,    0,  161,    2, 0x08,   10 /* Private */,
      12,    0,  162,    2, 0x08,   11 /* Private */,
      13,    0,  163,    2, 0x08,   12 /* Private */,
      14,    0,  164,    2, 0x08,   13 /* Private */,
      15,    0,  165,    2, 0x08,   14 /* Private */,
      16,    0,  166,    2, 0x08,   15 /* Private */,
      17,    0,  167,    2, 0x08,   16 /* Private */,
      18,    0,  168,    2, 0x08,   17 /* Private */,
      19,    0,  169,    2, 0x08,   18 /* Private */,
      20,    0,  170,    2, 0x08,   19 /* Private */,
      21,    0,  171,    2, 0x08,   20 /* Private */,
      22,    0,  172,    2, 0x08,   21 /* Private */,
      23,    1,  173,    2, 0x08,   22 /* Private */,
      25,    0,  176,    2, 0x08,   24 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->slotTimer(); break;
        case 1: _t->figures_draw_rectangle(); break;
        case 2: _t->figures_draw_ellipse(); break;
        case 3: _t->figures_draw_polygon(); break;
        case 4: _t->figures_draw_line(); break;
        case 5: _t->figures_draw_broken(); break;
        case 6: _t->figures_draw_freestyle(); break;
        case 7: _t->tools_move(); break;
        case 8: _t->tools_choose_pen_color(); break;
        case 9: _t->tools_choose_floodfill_color(); break;
        case 10: _t->tools_undo(); break;
        case 11: _t->tools_redo(); break;
        case 12: _t->tools_scale_up(); break;
        case 13: _t->tools_scale_down(); break;
        case 14: _t->tools_rotate_right(); break;
        case 15: _t->tools_rotate_left(); break;
        case 16: _t->tools_copy(); break;
        case 17: _t->tools_paste(); break;
        case 18: _t->tools_delete(); break;
        case 19: _t->tools_serialize(); break;
        case 20: _t->tools_de_serialize(); break;
        case 21: _t->on_penWidthBox_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 22: _t->on_choseButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t
, QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 23;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
