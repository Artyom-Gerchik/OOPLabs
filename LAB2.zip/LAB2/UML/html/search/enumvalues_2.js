var searchData=
[
  ['initial_0',['Initial',['../a00038.html#a2db0829141c827d2244332baa065cf15a3392b59c8aa0ec56670fbcd5638cbfde',1,'toolsenum.h']]]
];
