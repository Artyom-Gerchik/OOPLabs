var searchData=
[
  ['scale_0',['Scale',['../a00102.html#aa59bec67ae01521e5dd66f6a219c1875',1,'MainScene']]],
  ['setchosedbrushcolor_1',['SetChosedBrushColor',['../a00102.html#aec527a7dfc64415300c017a31035a5cf',1,'MainScene']]],
  ['setchosedcolor_2',['SetChosedColor',['../a00094.html#a46b510c0c8cdc73572cf0ec248f93b63',1,'FloodFill']]],
  ['setchosedfigure_3',['SetChosedFigure',['../a00102.html#ac8cdb54cfb76ba93aeddf25e10fe9e1b',1,'MainScene']]],
  ['setchosedpencolor_4',['SetChosedPenColor',['../a00102.html#acf285e51cd38ee6ac8e5559239105a6a',1,'MainScene']]],
  ['setchosedthickness_5',['SetChosedThickness',['../a00102.html#afdcaeb11bcf65ed91624f7c87dad799c',1,'MainScene']]],
  ['setchosedtool_6',['SetChosedTool',['../a00102.html#ac1763a213b4357f86822bd3d2d9a6718',1,'MainScene']]],
  ['setfigurecenterpoint_7',['SetFigureCenterPoint',['../a00090.html#a15d0f395d12e25b65c6dcf55a1ea9c96',1,'Figure']]],
  ['setfigureexternalrepresentation_8',['SetFigureExternalRepresentation',['../a00090.html#af7f8ecc5d9e673990c59c1a262270c4b',1,'Figure']]]
];
