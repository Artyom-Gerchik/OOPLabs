var searchData=
[
  ['ui_0',['Ui',['../a00074.html',1,'']]],
  ['undo_1',['Undo',['../a00102.html#a9dd783846d86d37f1d5298c8566c1f7b',1,'MainScene']]]
];
